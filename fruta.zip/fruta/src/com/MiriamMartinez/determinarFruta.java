package com.MiriamMartinez;

public class determinarFruta {
    public static void main(String[] args) {
        determinarFruta("Manzana");

    }

}
