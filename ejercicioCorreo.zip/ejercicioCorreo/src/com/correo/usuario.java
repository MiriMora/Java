package com.correo;

public class usuario {
    private String nombre;
    private String apellido;
    private int edad;
    private long altura;

    public String getNombre() {
        acceso acceso = new acceso();
        acceso.setIntentos(acceso.getIntentos() + 1);
        return nombre;
    }

    public void setNombre(String nombre) {
        enviarCorreo correo = new enviarCorreo();
        correo.enviarCorreoDeBienvenida(nombre);
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public long getAltura() {
        return altura;
    }

    public void setAltura(long altura) {
        this.altura = altura;
    }
}
