package com.correo;

public class enviarCorreo {
    public void enviarCorreoDeBienvenida(String nombre){

    }
    }

