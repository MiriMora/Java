package com.correo;

public class main {
    public static void main(String[] args) {

        usuario usuario = new usuario();
        usuario.setNombre("Miri");
        System.out.println(usuario.getNombre());

        usuario.setApellido("Martinez");
        System.out.println( "Apellido: " + usuario.getApellido());

        usuario.setEdad(28);
        System.out.println(usuario.getEdad());

        usuario.setAltura(166);
        System.out.println(usuario.getAltura());


    }
}
