package com.correo;

public class acceso {
    private int intentos = 0;

    public int getIntentos(){
        return intentos;
    }

    public void setIntentos(int intentos){
        this.intentos = intentos;
    }
}
