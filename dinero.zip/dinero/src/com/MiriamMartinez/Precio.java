package com.MiriamMartinez;

public interface Precio {
    double getPrecio();
}
