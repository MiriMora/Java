package com.MiriamMartinez;

public class PrecioFactory {
    private PrecioFactory(){}
    Precio precio;

    public PrecioFactory (String pais){

        if (pais.equalsIgnoreCase("España")){
            System.out.println("en España, precio en euro");
            precio = new PrecioEuro();
        } else if (pais.equalsIgnoreCase("UK")) {
            System.out.println("en UK, el precio en GBP");
            precio = new PrecioGBP();
        } else {
            System.out.println("En otro pais, el precio en USD");
            precio = new PrecioUSD();
        }
    }
}
