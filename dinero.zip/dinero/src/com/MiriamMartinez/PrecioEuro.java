package com.MiriamMartinez;

public class PrecioEuro {
    @Override
    public double getPrecio() {
        return 1.3 ;
    }
}
}
