package com.MiriamMartinez;

public class Main {
    public static void main(String[] args) {

        PrecioFactory precioFactory = new PrecioFactory("España");
        System.out.println(precioFactory.precio.getPrecio());

        PrecioFactory precioFactory1 = new PrecioFactory("EEUU");
        System.out.println(precioFactory1.precio.getPrecio());

        PrecioFactory precioFactory2 = new PrecioFactory("UK");
        System.out.println(precioFactory2.precio.getPrecio());
    }
}
