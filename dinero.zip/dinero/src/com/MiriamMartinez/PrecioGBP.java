package com.MiriamMartinez;

public class PrecioGBP {
    @Override
    public double getPrecio() {
        return 2.1 ;
    }
}
