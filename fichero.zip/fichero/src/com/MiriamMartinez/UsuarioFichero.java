package com.MiriamMartinez;

import java.io.File;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class UsuarioFichero {
    private String UsuarioFichero = "usuarios.txt";
    private PrintStream fichero;

    public void UsuarioFichero(){
        try {
            fichero = new PrintStream(fichero);
        } catch (Exception e){
            System.out.println("No puedo abrirlo" + e.getMessage());
        }
    }

    public void Crear(String nombre){
        fichero.println(nombre);
    }
    public ArrayList<String> listar(){

        ArrayList<String> usuarios = new ArrayList();

        try {
            Scanner scanner = new Scanner(new File(UsuarioFichero));
            while (scanner.hasNext()){
                usuarios.add(scanner.next());
            }
        }catch (Exception e){
            System.out.println("Error leyendo: " + e.getMessage());
        }
        return usuarios;
    }
}
