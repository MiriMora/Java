package com.MiriamMartinez;

public class Main {
    public static void main(String[] args) {

        UsuarioFichero usuarios = new UsuarioFichero();
        usuarios.Crear("Santi");
        usuarios.Crear("Olga");
        usuarios.Crear("Jaime");
        usuarios.Crear("Miri");


    }
}
